package org.example;

import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.AnswerCallbackQuery;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;

import java.util.ArrayList;
import java.util.List;

public class BakuBot extends TelegramLongPollingBot {

    // Owner ID - keep as long literal
    private final long OWNER_ID = 8123768337L;

    @Override
    public String getBotUsername() {
        return "MafiaBakuBIakBot";
    }

    @Override
    public String getBotToken() {
        // Load token from environment variable for security.
        String t = System.getenv("BOT_TOKEN");
        if (t == null || t.isBlank()) {
            System.err.println("BOT_TOKEN environment variable is not set. Exiting."); 
            // Return empty string - Telegram library will throw an error.
            return "";
        }
        return t;
    }

    @Override
    public void onUpdateReceived(Update update) {
        try {
            // Handle callback query (popup)
            if (update.hasCallbackQuery()) {
                String callbackData = update.getCallbackQuery().getData();
                if ("get_diamond".equals(callbackData)) {
                    AnswerCallbackQuery answer = new AnswerCallbackQuery();
                    answer.setCallbackQueryId(update.getCallbackQuery().getId());
                    answer.setText("💎 Sizning hisobingizga qo'shildi!"); // popup message
                    answer.setShowAlert(true);
                    execute(answer);
                }
                return;
            }

            if (!update.hasMessage() || !update.getMessage().hasText()) return;

            Message msg = update.getMessage();
            String text = msg.getText().trim();
            long chatId = msg.getChatId();
            long fromId = msg.getFrom().getId();

            // Only owner commands allowed
            if (fromId != OWNER_ID) return;

            if (text.equalsIgnoreCase("/start")) {
                sendStartMessage(chatId);
            } else if (text.startsWith("/sent ")) {
                handleSentWithLink(chatId, text);
            } else if (text.startsWith("/sentt ")) {
                handleSentWithPopup(chatId, text);
            }
        } catch (Exception e) {
            System.err.println("Error in onUpdateReceived: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void sendStartMessage(long chatId) {
        String messageText = "Salom!\nMen 🕵️ Mafia o'yini rasmiy botiman.";
        SendMessage message = new SendMessage(String.valueOf(chatId), messageText);

        // Inline keyboard
        List<List<InlineKeyboardButton>> rows = new ArrayList<>();

        List<InlineKeyboardButton> row1 = new ArrayList<>();
        InlineKeyboardButton addGame = new InlineKeyboardButton("🕹 O'yinni guruhga qo'shish");
        addGame.setUrl("https://t.me/MafiaBakuBIakBot?startgroup=true");
        row1.add(addGame);
        rows.add(row1);

        List<InlineKeyboardButton> row2 = new ArrayList<>();
        InlineKeyboardButton premium = new InlineKeyboardButton("🎲 Premium guruhlar");
        premium.setUrl("https://t.me/+A6mb0c71O3g0ZjUy");
        InlineKeyboardButton news = new InlineKeyboardButton("📰 Yangiliklar");
        news.setUrl("https://t.me/MafiaAzBot_news");
        row2.add(premium);
        row2.add(news);
        rows.add(row2);

        List<InlineKeyboardButton> row3 = new ArrayList<>();
        InlineKeyboardButton lang = new InlineKeyboardButton("🌍 Til");
        lang.setCallbackData("lang");
        InlineKeyboardButton rules = new InlineKeyboardButton("📜 O'yin qoidalari");
        rules.setUrl("https://t.me/mafqoida");
        row3.add(lang);
        row3.add(rules);
        rows.add(row3);

        InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
        markup.setKeyboard(rows);
        message.setReplyMarkup(markup);

        try {
            execute(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // /sent <amount> <url>
    private void handleSentWithLink(long chatId, String text) {
        try {
            String[] parts = text.split(" ", 3);
            if (parts.length < 3) {
                sendMessage(chatId, "❗ Format: /sent [son] [link]\nMasalan:\n/sent 200 https://t.me/...") ;
                return;
            }
            String amount = parts[1];
            String url = parts[2];

            String messageText = "ʍᴇҳᴩᴏж baham ko'rish 💎" + amount + " olmoslari!\n\n💎1 ta olish uchun bosing!";
            SendMessage message = new SendMessage(String.valueOf(chatId), messageText);

            InlineKeyboardButton button = new InlineKeyboardButton("💎 Olish");
            button.setUrl(url);

            List<InlineKeyboardButton> row = new ArrayList<>();
            row.add(button);
            List<List<InlineKeyboardButton>> keyboard = new ArrayList<>();
            keyboard.add(row);

            InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
            markup.setKeyboard(keyboard);
            message.setReplyMarkup(markup);

            execute(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // /sentt <amount>  -> popup alert
    private void handleSentWithPopup(long chatId, String text) {
        try {
            String[] parts = text.split(" ", 2);
            if (parts.length < 2) {
                sendMessage(chatId, "❗ Format: /sentt [son]\nMasalan: /sentt 200");
                return;
            }
            String amount = parts[1];
            String messageText = "ʍᴇҳᴩᴏж baham ko'rish 💎" + amount + " olmoslari!\n\n💎1 ta olish uchun bosing!";
            SendMessage message = new SendMessage(String.valueOf(chatId), messageText);

            InlineKeyboardButton button = new InlineKeyboardButton("💎 Olish");
            button.setCallbackData("get_diamond"); // handled in callbackQuery

            List<InlineKeyboardButton> row = new ArrayList<>();
            row.add(button);
            List<List<InlineKeyboardButton>> keyboard = new ArrayList<>();
            keyboard.add(row);

            InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
            markup.setKeyboard(keyboard);
            message.setReplyMarkup(markup);

            execute(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sendMessage(long chatId, String text) {
        try {
            execute(new SendMessage(String.valueOf(chatId), text));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
