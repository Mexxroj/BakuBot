Render deployment instructions (quick):
1. Upload this project to a new Git repository OR deploy by uploading zip to Render 'New Web Service' -> 'Deploy from a public Git repository' (you can push this repo to GitHub).
2. In Render service settings -> Environment -> Add environment variable:
   BOT_TOKEN = <your telegram bot token here>
   OWNER_ID = 8123768337
3. Build command (Render will auto-detect Maven):
   mvn -B -DskipTests package
4. Start command (Procfile will be used):
   web: java -jar target/baku-bot-1.0-jar-with-dependencies.jar
5. After deploy, check service logs. When running, the bot will respond to /sent and /sentt commands issued by OWNER_ID only.
IMPORTANT: Keep BOT_TOKEN secret. Do not commit it to public repos.
